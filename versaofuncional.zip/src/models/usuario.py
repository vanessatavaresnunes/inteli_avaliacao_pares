"""
Modelo de dados para usuários e configurações do sistema.
Responsável por gerenciar dados de alunos, times e configurações.
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass
import unicodedata


@dataclass
class Configuracao:
    """Classe que representa as configurações do sistema"""
    nota_minima: int
    nota_maxima: int
    diretorio_dados: str


class UsuarioModel:
    """Modelo responsável por gerenciar dados de usuários e configurações"""
    
    def __init__(self, diretorio_config: str = "data"):
        """
        Inicializa o modelo carregando dados dos arquivos JSON
        
        Args:
            diretorio_config: Diretório onde estão os arquivos de configuração
        """
        self.diretorio_config = diretorio_config
        self.turma_atual = None
        self.alunos = {}
        self.eixos = self._carregar_eixos()
        self.config = self._carregar_configuracao()

    def obter_turmas(self) -> list:
        """Lista os arquivos de alunos_<turma>.json e retorna as turmas disponíveis."""
        turmas = []
        for arquivo in os.listdir(self.diretorio_config):
            if arquivo.startswith("alunos_") and arquivo.endswith(".json"):
                nome = arquivo[len("alunos_"):-len(".json")]
                turmas.append(nome)
        # Compatibilidade: se existir alunos.json, adiciona 'default' ou 'unica'
        if os.path.exists(os.path.join(self.diretorio_config, "alunos.json")):
            turmas.append("unica")
        return sorted(turmas)
    
    def _carregar_alunos(self, turma: str = None) -> Dict[str, List[Dict[str, str]]]:
        """Carrega dados dos alunos do arquivo JSON da turma informada ou padrão."""
        try:
            if turma and turma != "unica":
                caminho_arquivo = Path(self.diretorio_config) / f"alunos_{turma}.json"
            else:
                caminho_arquivo = Path(self.diretorio_config) / "alunos.json"
            with open(caminho_arquivo, 'r', encoding='utf-8') as arquivo:
                return json.load(arquivo)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"Erro ao carregar alunos da turma '{turma}': {e}")
            return {}

    def set_turma(self, turma: str):
        """Define a turma atual e carrega os alunos dessa turma."""
        self.turma_atual = turma
        self.alunos = self._carregar_alunos(turma)

    def validar_senha(self, time: str, aluno: str, senha: str) -> bool:
        """
        Valida a senha de um aluno
        
        Args:
            time: Nome do time
            aluno: Nome do aluno
            senha: Senha a ser verificada
            
        Returns:
            True se a senha estiver correta, False caso contrário
        """
        if time in self.alunos:
            for a in self.alunos[time]:
                if a['nome'] == aluno and a['senha'] == senha:
                    return True
        return False
    
    def _carregar_eixos(self) -> List[Dict[str, any]]:
        """Carrega eixos de avaliação do arquivo JSON"""
        try:
            caminho_arquivo = Path(self.diretorio_config) / "eixos.json"
            with open(caminho_arquivo, 'r', encoding='utf-8') as arquivo:
                eixos_data = json.load(arquivo)
                for eixo in eixos_data:
                    eixo['nome'] = unicodedata.normalize('NFC', eixo['nome'])
                    eixo['descricao'] = unicodedata.normalize('NFC', eixo['descricao'])
                    if 'observacoes' in eixo:
                        eixo['observacoes'] = [unicodedata.normalize('NFC', obs) for obs in eixo['observacoes']]
                return eixos_data
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"Erro ao carregar eixos.json: {e}")
            return []
    
    def _carregar_configuracao(self) -> Dict:
        """Carrega configurações do sistema do arquivo JSON"""
        try:
            caminho_arquivo = Path(self.diretorio_config) / "config.json"
            with open(caminho_arquivo, 'r', encoding='utf-8') as arquivo:
                return json.load(arquivo)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            print(f"Erro ao carregar config.json: {e}")
            return {"nota_minima": 0, "nota_maxima": 3}
    
    def obter_times(self, turma: str = None) -> List[str]:
        """Retorna lista de times disponíveis para a turma informada ou atual."""
        if turma:
            alunos = self._carregar_alunos(turma)
            return list(alunos.keys())
        return list(self.alunos.keys())

    def obter_alunos_por_time(self, time: str, turma: str = None) -> List[Dict[str, any]]:
        """
        Retorna lista de alunos de um time específico para a turma informada ou atual.
        """
        if turma:
            alunos = self._carregar_alunos(turma)
            return alunos.get(time, [])
        return self.alunos.get(time, [])
    
    def obter_alunos_time_excluindo(self, time: str, aluno_excluir: str, turma: str = None) -> List[Dict[str, any]]:
        """
        Retorna lista de alunos de um time excluindo um aluno específico
        Args:
            time: Nome do time
            aluno_excluir: Nome do aluno a ser excluído
            turma: Turma a ser considerada
        Returns:
            Lista de alunos do time sem o aluno excluído
        """
        alunos_time = self.obter_alunos_por_time(time, turma)
        return [aluno for aluno in alunos_time if aluno['nome'] != aluno_excluir]
    
    def obter_aluno_por_nome(self, nome_aluno: str) -> Optional[Dict[str, any]]:
        """
        Retorna os dados de um aluno pelo nome.

        Args:
            nome_aluno: Nome do aluno a ser buscado.

        Returns:
            Dicionário com os dados do aluno ou None se não encontrado.
        """
        for time in self.alunos.values():
            for aluno in time:
                if unicodedata.normalize('NFC', aluno['nome']) == unicodedata.normalize('NFC', nome_aluno):
                    return aluno
        return None

    def obter_aluno_por_id(self, id_aluno: int) -> Optional[Dict[str, any]]:
        """
        Retorna os dados de um aluno pelo ID.

        Args:
            id_aluno: ID do aluno a ser buscado.

        Returns:
            Dicionário com os dados do aluno ou None se não encontrado.
        """
        for time in self.alunos.values():
            for aluno in time:
                if aluno['id'] == id_aluno:
                    return aluno
        return None

    def obter_id_aluno(self, nome_aluno: str) -> Optional[int]:
        """
        Retorna o ID de um aluno pelo nome.

        Args:
            nome_aluno: Nome do aluno.

        Returns:
            ID do aluno ou None se não encontrado.
        """
        aluno = self.obter_aluno_por_nome(nome_aluno)
        return aluno['id'] if aluno else None

    def obter_nome_aluno(self, id_aluno: int, turma: str = None) -> Optional[str]:
        """
        Retorna o nome de um aluno pelo ID, considerando a turma se informada.
        Args:
            id_aluno: ID do aluno.
            turma: Turma a ser considerada (opcional)
        Returns:
            Nome do aluno ou None se não encontrado.
        """
        if turma:
            alunos = self._carregar_alunos(turma)
            for grupo in alunos.values():
                for aluno in grupo:
                    if aluno['id'] == id_aluno:
                        return aluno['nome']
            return None
        else:
            aluno = self.obter_aluno_por_id(id_aluno)
            return aluno['nome'] if aluno else None

    def obter_eixos(self) -> List[Dict[str, any]]:
        """Retorna lista de eixos de avaliação com nome, descrição e observações"""
        return self.eixos.copy()
    
    def obter_nomes_eixos(self) -> List[str]:
        """Retorna lista apenas com os nomes dos eixos de avaliação"""
        return [eixo["nome"] for eixo in self.eixos]
    
    def obter_descricao_eixo(self, nome_eixo: str) -> str:
        """
        Retorna a descrição de um eixo específico
        
        Args:
            nome_eixo: Nome do eixo
            
        Returns:
            Descrição do eixo ou string vazia se não encontrado
        """
        for eixo in self.eixos:
            if unicodedata.normalize('NFC', eixo["nome"]) == unicodedata.normalize('NFC', nome_eixo):
                return eixo["descricao"]
        return ""
    
    def obter_observacoes_eixo(self, nome_eixo: str) -> List[str]:
        """
        Retorna as observações de um eixo específico
        
        Args:
            nome_eixo: Nome do eixo
            
        Returns:
            Lista de observações do eixo ou lista vazia se não encontrado
        """
        for eixo in self.eixos:
            if unicodedata.normalize('NFC', eixo["nome"]) == unicodedata.normalize('NFC', nome_eixo):
                return eixo.get("observacoes", [])
        return []
    
    def obter_configuracao(self) -> Dict:
        """Retorna configurações do sistema"""
        return self.config
    
    def validar_time(self, time: str) -> bool:
        """
        Valida se um time existe
        
        Args:
            time: Nome do time
            
        Returns:
            True se o time existe, False caso contrário
        """
        return time in self.alunos
    
    def validar_aluno(self, time: str, aluno: str) -> bool:
        """
        Valida se um aluno pertence a um time
        
        Args:
            time: Nome do time
            aluno: Nome do aluno
            
        Returns:
            True se o aluno pertence ao time, False caso contrário
        """
        if time in self.alunos:
            return any(unicodedata.normalize('NFC', a['nome']) == unicodedata.normalize('NFC', aluno) for a in self.alunos[time])
        return False
